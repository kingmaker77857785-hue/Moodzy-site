MOODZY WEBSITE PACKAGE — READ FIRST

Upload these files to the ROOT of your website repository:
- index.html: Moodzy app page based on the current all-features HTML preview.
- manifest.webmanifest: installable app metadata.
- sw.js: basic service worker cache.
- moodzy-192.png and moodzy-512.png: app icons made from your Moodzy logo.
- download.html: separate download landing page; its APK button is intentionally a placeholder until a real APK exists.

IMPORTANT:
1) This is a website/PWA source package, NOT an APK.
2) The UPI ID is shown as reference only. Payments are NOT processed or verified, and Premium is not automatically unlocked. Do not represent this preview as a working checkout.
3) The login form is a preview, not real authentication. The Premium page now lists intended Premium-only features, but feature locks are not enforced until real subscription verification and server-side entitlement checks are implemented.
4) All files in a public website repository are public. Never upload passwords, secret API keys, signing keys, or private owner/admin controls.
5) Keep your Android signing key and credentials private.

PUBLISH WEBSITE FROM YOUR ANDROID PHONE:
1. Download this ZIP and extract it in the Android Files app.
2. In Chrome, open github.com and sign in/create an account.
3. Create a new PUBLIC repository named moodzy-site. Public repositories are required for GitHub Pages on GitHub Free.
4. Open the repository and choose Add file > Upload files. Select the files listed above from the extracted folder. Upload them to the repository ROOT, not inside another folder. Commit the changes.
5. Open repository Settings > Pages. Under Build and deployment choose Deploy from a branch, branch main, folder /(root), then Save.
6. Wait a few minutes; use the website URL shown in Pages settings. The app page is index.html; the download page is /download.html.
7. Test it on your own phone. GitHub Pages websites are public.

BUILD AN ANDROID APK AFTER WEBSITE WORKS:
1. Open https://www.pwabuilder.com/ and enter your HTTPS website URL.
2. Review PWA checks and correct issues if shown.
3. Choose Package for stores > Android. For a test/direct APK, use the Other Android option if offered. For Google Play, use the Google Play option and follow its AAB/signing steps.
4. Download the generated package ZIP, extract it, and read its included instructions. Install the APK on your phone and test it before sharing.
5. For a download link, upload the actual signed APK to a release page or website. Then edit download.html and replace the placeholder button with the real APK URL. Never link to a file that does not exist.
6. Save the signing key securely for future updates.

GOOGLE PLAY NOTE:
The Play Store generally requires an Android App Bundle (.aab), a developer account, and compliance with current testing and policy rules. Check current Google Play Console requirements and fees before paying or publishing.
